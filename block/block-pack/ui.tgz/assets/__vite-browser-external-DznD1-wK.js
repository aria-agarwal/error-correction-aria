import{t as e}from"./chunk-DECur_0Z.js";var t=e(((e,t)=>{t.exports={}}));export default t();
//# sourceMappingURL=__vite-browser-external-DznD1-wK.js.map